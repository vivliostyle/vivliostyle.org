---
title: Body
body:
  class: 'foo bar'
vfm:
  hardLineBreaks: false
---

This manuscript is written in [VFM (Vivliostyle Flavored Markdown)](https://docs.vivliostyle.org/en/vfm/). Please refer to the documentation for details.

# Source Code {#code}

```javascript
function main() {}
```

## With Caption {#code-with-caption}

```javascript:app.js
function main() {}
```

or

```javascript title=app.js
function main() {}
```

# Footnotes {#footnotes}

VFM is developed on a GitHub repository[^1].
Issues are managed on GitHub[^issues].
Footnotes can also be written inline^[This is a footnote.].

[^1]: [VFM](https://github.com/vivliostyle/vfm)
[^issues]: [Issues](https://github.com/vivliostyle/vfm/issues)

# Frontmatter {#frontmatter}

You can set metadata at the beginning of a Markdown file. For details, see [Frontmatter part in VFM document](https://docs.vivliostyle.org/en/vfm/).

# Line Breaks {#newline}

By default, line breaks occur when you insert a blank line. If you set `hardLineBreaks` to `true` in the frontmatter, line breaks occur without blank lines.

Hello.

Welcome to the world of Vivliostyle Flavored Markdown (VFM for short).
VFM is a Markdown dialect suited for writing publications, designed and implemented for the Vivliostyle project.

# Images {#figure}

![](https://vivliostyle.org/assets/vivliostyle-logo.svg)

## With Caption {#figure-with-caption}

![Vivliostyle Logo](https://vivliostyle.org/assets/vivliostyle-logo.svg)

![Vivliostyle Logo](https://vivliostyle.org/assets/vivliostyle-logo.svg 'Distributed on the official website'){id="image" data-sample="sample"}

# Math {#math}

Inline: $x = y$

Display: $$1 + 1 = 2$$

# HTML {#html}

<div class="custom">
  <p>Hey</p>
</div>

## Markdown and HTML Combined {#html-with-markdown}

<div class="custom">

- hoge
- fuga

</div>

# Ruby {#ruby}

This is {Ruby|ルビ}
