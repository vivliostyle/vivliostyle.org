<nav id="toc" role="doc-toc">

1. [Preface](preface.html)
1. [Body](body.html)
    1. [Source Code](body.html#code)
        1. [With Caption](body.html#code-with-caption)
    1. [Footnotes](body.html#footnote)
    1. [Frontmatter](body.html#frontmatter)
    1. [Line Breaks](body.html#newline)
    1. [Images](body.html#figure)
        1. [With Caption](body.html#figure-with-caption)
    1. [Math](body.html#math)
    1. [HTML](body.html#html)
        1. [Mixing Markdown and HTML](body.html#html-with-markdown)
    1. [Ruby](body.html#ruby)
1. [Afterword](afterword.html)

</nav>
